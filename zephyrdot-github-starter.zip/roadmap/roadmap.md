# Hackathon Roadmap (April 7 – May 4)

## ✅ Week 1 (April 7–13)
- Finalize architecture design (Substrate ↔ Zephyr)
- Setup base repo structure
- Collect Polkadot SDK & Zephyr RTOS integration examples

## 🧪 Week 2 (April 14–20)
- Build minimal working prototype of command relay (Substrate → Zephyr)
- Start writing technical docs/tutorials
- Create device simulator with LEDs or actuators

## 🌉 Week 3 (April 21–27)
- Implement cross-chain compatibility using XCM SDK
- Extend Zephyr device support with verification and secure key storage
- Polish technical documentation and create demo scripts

## 🚀 Week 4 (April 28–May 4)
- Final testing and integration
- Record walkthroughs and final video demo
- Submit on hackathon portal, finalize GitHub
