# ZephyrDot: Bridging IoT & Polkadot

**ZephyrDot** is a cross-chain IoT blockchain interface that enables developers using Zephyr RTOS to interact directly with Polkadot-based smart contracts. It focuses on security, scalability, and interoperability — allowing IoT protocols to migrate from Web2 to Web3 seamlessly.

## 🧠 Project Goals

- Enable Substrate smart contracts to issue commands to Zephyr-based microcontrollers
- Build a gateway that communicates securely via XCM or light relay nodes
- Ensure lightweight compatibility with constrained devices

## 📆 Hackathon Roadmap

See [`roadmap/roadmap.md`](roadmap/roadmap.md)

## 📂 Key Resources

- [Framework for IoT + Blockchain Integration](docs/framework-for-integrating-blockchain-with-iot-devices-whitepaper.pdf)
- [Polkadot for Developers - Encode Club](docs/Polkadot for Developers -Encode Club.pdf)
- [Thesis on IoT + Blockchain + Multichain](docs/IoT communications with blockchain and multi-chain.pdf)
